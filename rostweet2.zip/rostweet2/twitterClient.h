#include <cstdio>
#include <iostream>
#include <fstream>
#include "include/twitcurl.h"